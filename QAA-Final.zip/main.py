from faker import Faker
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

fake = Faker()

name = fake.name()
email = fake.email()
phone = fake.phone_number()
subject = fake.text(max_nb_chars=10)
description = fake.text()

url = "https://automationintesting.online/message/"

payload = {
    "name": name,
    "email": email,
    "phone": phone,
    "subject": subject,
    "description": description
}

response = requests.post(url, json=payload)

if response.status_code == 200:
    response_data = response.json()
    extracted_email = response_data.get("email", "")
    print(f"Extracted email: {extracted_email}")
else:
    extracted_email = ""
    print(f"Request failed with status code: {response.status_code}")

if extracted_email:
    chrome_options = Options()
    chrome_options.add_argument("--headless")

    service = Service("path/to/chromedriver")  # Adjust the path to chromedriver
    driver = webdriver.Chrome(service=service, options=chrome_options)

    try:
        driver.get("https://getbootstrap.com/docs/4.0/components/forms/")

        email_input = driver.find_element(By.ID, "exampleInputEmail1")
        email_input.send_keys(extracted_email)

        entered_email = email_input.get_attribute("value")
        assert entered_email == extracted_email, f"Email does not match: {entered_email} != {extracted_email}"
        print("Email entry verified successfully")

    finally:
        driver.quit()
